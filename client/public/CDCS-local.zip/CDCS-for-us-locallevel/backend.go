package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math/rand"
	"mime"
	"net/http"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/cockroachdb/pebble"
	"github.com/hashicorp/raft"
	"github.com/shirou/gopsutil/v3/disk"
	"google.golang.org/grpc"
)

// ShardMapping links a shard ID to the node currently holding it.
type ShardMapping struct {
	ShardID string `json:"shard_id"`
	NodeID  string `json:"node_id"`
}

// FileMeta holds everything the backend tracks about one uploaded file.
type FileMeta struct {
	ID           string            `json:"id"`
	Name         string            `json:"name"`
	Size         int64             `json:"size"` // original, unpadded byte length
	Mappings     []ShardMapping    `json:"mappings"`
	ChunkMap     map[string]string `json:"chunk_map"`
	BackupMap    map[string]string `json:"backup_map"`
	HomeMap      map[string]string `json:"home_map"` // chunk's permanent primary node
	DataShards   int               `json:"data_shards"`
	ParityShards int               `json:"parity_shards"`
	ShardSize    int               `json:"shard_size"`
	ChecksumMap  map[string]string `json:"checksum_map"`
	LastAccessed int64             `json:"last_accessed"`
	IsPinned     bool              `json:"is_pinned"`
	UploadedAt   int64             `json:"uploaded_at"`
}

// uploadWALEntry is a durable "upload in progress" record, written before any
// shard bytes go out and cleared once FileMeta is committed, so a crash
// mid-upload can be cleaned up on restart instead of leaving orphaned shards.
type uploadWALEntry struct {
	FileID    string `json:"file_id"`
	StartedAt int64  `json:"started_at"`
}

// NodeStatus reports whether a node is online/offline for the dashboard.
type NodeStatus struct {
	ID       string `json:"id"`
	Addr     string `json:"addr"`
	Status   string `json:"status"`
	IsBackup bool   `json:"is_backup"`
}

// Backend holds the cluster configuration, running servers, and metadata DB.
// All node-to-node/gRPC communication goes through cc (client.go); Backend
// itself never dials gRPC directly.
type Backend struct {
	nodeAddrs   map[string]string
	backupNodes map[string]bool
	servers     map[string]*grpc.Server
	nodeEngines map[string]*TwoQEngine // per-node 2Q cache, for /cache-stats
	fileMeta    map[string]FileMeta
	db          *pebble.DB
	cc          *ClusterClient
	mu          sync.RWMutex
	raftNodes   map[string]*raft.Raft
	raftAddrs   map[string]string
	standbyRaft []string

	// sfGroup collapses concurrent downloads of the same fileID into one
	// execution (see singleflight.go). sfTotal/sfDeduped are stats for the
	// dashboard: how many download calls came in vs. how many of those rode
	// along on someone else's in-flight fetch instead of doing their own work.
	sfGroup   *SingleFlightGroup
	sfTotal   int64
	sfDeduped int64
}

var fileIDSanitizer = regexp.MustCompile(`[^a-zA-Z0-9._-]+`)

// sanitizeFileID strips anything that isn't a safe filename character, since
// fileID is embedded directly in gRPC shard keys, Pebble keys, and (via
// node.go) on-disk paths under node_storage/<node>/<key>. This also blocks
// path traversal via "../" segments.
func sanitizeFileID(id string) string {
	id = strings.ReplaceAll(id, "..", "")
	id = fileIDSanitizer.ReplaceAllString(id, "_")
	if id == "" {
		id = fmt.Sprintf("file_%d", time.Now().UnixNano())
	}
	return id
}

// shardChecksum computes a hex-encoded checksum for a shard's bytes.
func shardChecksum(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:])
}

// verifyChecksum reports whether data matches a previously recorded checksum.
func verifyChecksum(data []byte, want string) bool {
	if want == "" {
		return true
	}
	return shardChecksum(data) == want
}

// shardIndexOf pulls the numeric index back out of a ShardID like
// "shard_3" -> 2 (0-based), matching the index PushShard/FetchShard expect.
func shardIndexOf(shardID string) uint32 {
	n, _ := strconv.Atoi(strings.TrimPrefix(shardID, "shard_"))
	if n <= 0 {
		return 0
	}
	return uint32(n - 1)
}

// NewBackend opens the Pebble metadata DB, loads past files, cleans up any
// upload that crashed mid-write, and builds the cluster client used for all
// node-to-node communication.
func NewBackend(nodeAddrs map[string]string, servers map[string]*grpc.Server, nodeEngines map[string]*TwoQEngine) *Backend {
	db, err := pebble.Open("metadata.db", &pebble.Options{})
	if err != nil {
		panic(fmt.Sprintf("Failed to open backend metadata Pebble DB: %v", err))
	}

	b := &Backend{
		nodeAddrs:   nodeAddrs,
		backupNodes: map[string]bool{"Node-07": true, "Node-08": true},
		servers:     servers,
		nodeEngines: nodeEngines,
		fileMeta:    make(map[string]FileMeta),
		db:          db,
		cc:          NewClusterClient(nodeAddrs),
		standbyRaft: []string{"Raft-06", "Raft-07"},
		sfGroup:     NewSingleFlightGroup(),
	}

	b.loadMetadataFromDB()
	b.recoverIncompleteUploads()
	b.startUnifiedSweeper(".", 90.0, 75.0)
	return b
}

func (b *Backend) loadMetadataFromDB() {
	b.mu.Lock()
	defer b.mu.Unlock()

	iter, err := b.db.NewIter(&pebble.IterOptions{LowerBound: []byte("file:"), UpperBound: []byte("file;")})
	if err != nil {
		return
	}
	defer iter.Close()

	for iter.First(); iter.Valid(); iter.Next() {
		var meta FileMeta
		if err := json.Unmarshal(iter.Value(), &meta); err == nil {
			b.fileMeta[meta.ID] = meta
		}
	}
}

func (b *Backend) walKey(fileID string) []byte { return fmt.Appendf(nil, "wal:%s", fileID) }

func (b *Backend) beginUploadWAL(fileID string) {
	entry := uploadWALEntry{FileID: fileID, StartedAt: time.Now().Unix()}
	if data, err := json.Marshal(entry); err == nil {
		_ = b.db.Set(b.walKey(fileID), data, pebble.Sync)
	}
}

func (b *Backend) commitUploadWAL(fileID string) {
	_ = b.db.Delete(b.walKey(fileID), pebble.Sync)
}

// saveMeta persists meta to Pebble and updates the in-memory copy. Factors
// out the repeated marshal+Set+map-update pattern used by upload/kill/
// revive/download handlers.
func (b *Backend) saveMeta(fileID string, meta FileMeta) error {
	var leaderNode *raft.Raft
	for _, r := range b.raftNodes {
		if r.State() == raft.Leader {
			leaderNode = r
			break
		}
	}

	if leaderNode == nil {
		return fmt.Errorf("cluster has no active leader (loss of quorum)")
	}

	cmd := LogCommand{Op: "SET_META", Key: fileID, Data: meta}
	cmdBytes, _ := json.Marshal(cmd)

	future := leaderNode.Apply(cmdBytes, 5*time.Second)
	return future.Error()
}

// recoverIncompleteUploads runs once at startup, purging orphaned shards from
// any upload whose WAL entry was never cleared (i.e. the process crashed
// mid-upload before FileMeta was committed).
func (b *Backend) recoverIncompleteUploads() {
	iter, err := b.db.NewIter(&pebble.IterOptions{LowerBound: []byte("wal:"), UpperBound: []byte("wal;")})
	if err != nil {
		return
	}

	var pending []string
	for iter.First(); iter.Valid(); iter.Next() {
		var entry uploadWALEntry
		if err := json.Unmarshal(iter.Value(), &entry); err == nil {
			pending = append(pending, entry.FileID)
		}
	}
	iter.Close()

	ctx := context.Background()
	for _, fileID := range pending {
		if _, committed := b.fileMeta[fileID]; committed {
			b.commitUploadWAL(fileID)
			continue
		}
		for i := 0; i < rsTotalShards; i++ {
			for nodeID := range b.nodeAddrs {
				_ = b.cc.DeleteShard(ctx, nodeID, fileID, uint32(i))
			}
		}
		b.commitUploadWAL(fileID)
	}
}

// HandleNodes reports every node's online/offline status to the frontend.
func (b *Backend) HandleNodes(w http.ResponseWriter, r *http.Request) {
	var statuses []NodeStatus
	for id, addr := range b.nodeAddrs {
		status := "ONLINE"
		if !b.cc.PingNode(id) {
			status = "OFFLINE"
		}
		statuses = append(statuses, NodeStatus{ID: id, Addr: addr, Status: status, IsBackup: b.backupNodes[id]})
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(statuses)
}

/// Helper to safely find the active Raft leader without triggering a concurrent map read/write panic
func (b *Backend) getLeader() *raft.Raft {
	b.mu.RLock()
	defer b.mu.RUnlock()
	for _, r := range b.raftNodes {
		if r.State() == raft.Leader {
			return r
		}
	}
	return nil
}

// ----------------------------------------------------------------------
// FULLY INTEGRATED KILL NODE (Raft Shutdown + Reed-Solomon Failover)
// ----------------------------------------------------------------------
func (b *Backend) HandleKillNode(w http.ResponseWriter, r *http.Request) {
	nodeID := r.URL.Query().Get("id")

	// 1. Safely disconnect from the cluster maps
	b.mu.Lock()
	srv, srvExists := b.servers[nodeID]
	if srvExists {
		delete(b.servers, nodeID)
	}
	b.mu.Unlock()

	// 2. Shut down the actual network listeners
	if srvExists && srv != nil {
		srv.Stop()
		fmt.Printf("=> gRPC server stopped on %s\n", nodeID)
	}

	// 3. RS Failover: Reroute traffic safely without corrupting memory
	b.mu.RLock()
	filesToUpdate := make(map[string]FileMeta)

	for fileID, meta := range b.fileMeta {
		needsUpdate := false

		// Deep-copy the map so we don't accidentally mutate the live database directly
		newChunkMap := make(map[string]string)
		for k, v := range meta.ChunkMap {
			newChunkMap[k] = v
		}

		// Deep-copy Mappings too, since we now update NodeID alongside ChunkMap
		// so the dashboard (which reads f.mappings) reflects the reroute.
		newMappings := make([]ShardMapping, len(meta.Mappings))
		copy(newMappings, meta.Mappings)

		for i, mapping := range newMappings {
			chunkID := fmt.Sprintf("%s_%s", fileID, mapping.ShardID)
			if newChunkMap[chunkID] == nodeID {
				newChunkMap[chunkID] = meta.BackupMap[chunkID]
				newMappings[i].NodeID = meta.BackupMap[chunkID]
				needsUpdate = true
			}
		}

		if needsUpdate {
			meta.ChunkMap = newChunkMap
			meta.Mappings = newMappings
			filesToUpdate[fileID] = meta
		}
	}
	b.mu.RUnlock()

	// 4. Submit the rerouted maps to the Raft control plane
	leader := b.getLeader()
	if leader != nil {
		for fileID, meta := range filesToUpdate {
			cmd := LogCommand{Op: "SET_META", Key: fileID, Data: meta}
			cmdBytes, _ := json.Marshal(cmd)
			leader.Apply(cmdBytes, 5*time.Second)
			fmt.Printf("=> RS Failover: Rerouted shards for file %s\n", fileID)
		}
	}

	w.WriteHeader(http.StatusOK)
}

// ----------------------------------------------------------------------
// FULLY INTEGRATED REVIVE NODE (Raft Reboot + Reed-Solomon Restoration)
// ----------------------------------------------------------------------
func (b *Backend) HandleReviveNode(w http.ResponseWriter, r *http.Request) {
	nodeID := r.URL.Query().Get("id")

	// 1. Grab addresses
	b.mu.RLock()
	_, isRunning := b.servers[nodeID]
	grpcAddr := b.nodeAddrs[nodeID]
	b.mu.RUnlock()

	if !isRunning {
		// 2. Restart gRPC Muscle
		newSrv, newEngine, err := StartNode(nodeID, grpcAddr)
		if err == nil {
			b.mu.Lock()
			b.servers[nodeID] = newSrv
			b.nodeEngines[nodeID] = newEngine
			b.cc = NewClusterClient(b.nodeAddrs)
			b.mu.Unlock()
			fmt.Printf("=> gRPC server revived on %s\n", nodeID)
		}
	}

	// 4. RS Restoration: Pull shards back from the backup nodes
	ctx := context.Background()
	b.mu.RLock()
	filesToUpdate := make(map[string]FileMeta)

	for fileID, meta := range b.fileMeta {
		needsUpdate := false

		// Deep-copy the map for safe mutation
		newChunkMap := make(map[string]string)
		for k, v := range meta.ChunkMap {
			newChunkMap[k] = v
		}

		// Deep-copy Mappings too, so NodeID stays in sync with ChunkMap
		// once a chunk is restored home.
		newMappings := make([]ShardMapping, len(meta.Mappings))
		copy(newMappings, meta.Mappings)

		for i, mapping := range newMappings {
			chunkID := fmt.Sprintf("%s_%s", fileID, mapping.ShardID)

			// If this chunk belongs here, but is currently stuck on the backup node
			if meta.HomeMap[chunkID] == nodeID && newChunkMap[chunkID] != nodeID {

				shardUint := shardIndexOf(mapping.ShardID)
				backupNode := newChunkMap[chunkID]

				// Catch the data AND the checksum from GetShard
				data, checksum, err := b.cc.GetShard(ctx, backupNode, fileID, shardUint)

				if err == nil {
					storeErr := b.cc.PutShard(ctx, nodeID, fileID, shardUint, data, checksum)
					if storeErr == nil {
						newChunkMap[chunkID] = nodeID // Restore it home
						newMappings[i].NodeID = nodeID
						needsUpdate = true
					}
				}
			}
		}

		if needsUpdate {
			meta.ChunkMap = newChunkMap
			meta.Mappings = newMappings
			filesToUpdate[fileID] = meta
		}
	}
	b.mu.RUnlock()

	// 5. Submit the restored maps to the Raft control plane
	leader := b.getLeader()
	if leader != nil {
		for fileID, meta := range filesToUpdate {
			cmd := LogCommand{Op: "SET_META", Key: fileID, Data: meta}
			cmdBytes, _ := json.Marshal(cmd)
			leader.Apply(cmdBytes, 5*time.Second)
			fmt.Printf("=> RS Restoration: Pulled shards back home to %s for file %s\n", nodeID, fileID)
		}
	}

	w.WriteHeader(http.StatusOK)
}
func (b *Backend) HandleUpload(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	if err := r.ParseMultipartForm(32 << 20); err != nil {
		http.Error(w, "Failed to parse multipart form", http.StatusBadRequest)
		return
	}

	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "Failed to read uploaded file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	fileID := r.FormValue("id")
	if fileID == "" {
		fileID = header.Filename
	}
	fileID = sanitizeFileID(fileID)

	fileBytes, err := io.ReadAll(file)
	if err != nil {
		http.Error(w, "Failed to read file contents", http.StatusInternalServerError)
		return
	}

	ctx := context.Background()

	// Reject re-uploading under an ID that's already in use, instead of
	// silently overwriting the existing file. The user should pick a
	// different ID or delete the existing file first.
	b.mu.Lock()
	if _, exists := b.fileMeta[fileID]; exists {
		b.mu.Unlock()
		http.Error(w, fmt.Sprintf("File ID '%s' is already in use. Choose a different ID or delete the existing file first.", fileID), http.StatusConflict)
		return
	}
	b.mu.Unlock()

	b.beginUploadWAL(fileID)

	// Node-01..06 each hold one RS shard (4 data + 2 parity); Node-07/08 are
	// plain full-copy backups, not part of the RS math.
	mainNodes := []string{"Node-01", "Node-02", "Node-03", "Node-04", "Node-05", "Node-06"}
	backupNodesList := []string{"Node-07", "Node-08"}

	rGen := rand.New(rand.NewSource(time.Now().UnixNano()))
	rGen.Shuffle(len(mainNodes), func(i, j int) { mainNodes[i], mainNodes[j] = mainNodes[j], mainNodes[i] })

	shards, shardSize, err := encodeFileToShards(fileBytes)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	chunkMap := make(map[string]string)
	backupMap := make(map[string]string)
	homeMap := make(map[string]string)
	checksumMap := make(map[string]string)
	var mappings []ShardMapping

	for i := 0; i < rsTotalShards; i++ {
		chunkData := shards[i]
		shardID := fmt.Sprintf("shard_%d", i+1)
		fullChunkKey := fmt.Sprintf("%s_%s", fileID, shardID)
		checksum := shardChecksum(chunkData)
		checksumMap[fullChunkKey] = checksum

		homeNode := mainNodes[i%len(mainNodes)]
		backupNode := backupNodesList[i%len(backupNodesList)]

		targetNode := homeNode
		if err := b.cc.PutShard(ctx, targetNode, fileID, uint32(i), chunkData, checksum); err != nil {
			targetNode = backupNode
		}
		if targetNode != backupNode {
			_ = b.cc.PutShard(ctx, backupNode, fileID, uint32(i), chunkData, checksum)
		}

		chunkMap[fullChunkKey] = targetNode
		backupMap[fullChunkKey] = backupNode
		homeMap[fullChunkKey] = homeNode
		mappings = append(mappings, ShardMapping{ShardID: shardID, NodeID: targetNode})
	}

	meta := FileMeta{
		ID: fileID, Name: header.Filename, Size: int64(len(fileBytes)),
		Mappings: mappings, ChunkMap: chunkMap, BackupMap: backupMap, HomeMap: homeMap,
		DataShards: rsDataShards, ParityShards: rsParityShards, ShardSize: shardSize,
		ChecksumMap: checksumMap, LastAccessed: time.Now().Unix(),UploadedAt:   time.Now().Unix(),
	}

	// DO NOT USE b.mu.Lock() HERE. Just call saveMeta directly!
	if err := b.saveMeta(fileID, meta); err != nil {
		http.Error(w, "Consensus failed: "+err.Error(), http.StatusInternalServerError)
		return
	}

	b.commitUploadWAL(fileID)

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Upload successful"))
}

// HandleFiles returns the list of all stored files to the frontend.
func (b *Backend) HandleFiles(w http.ResponseWriter, r *http.Request) {
	b.mu.RLock()
	defer b.mu.RUnlock()

	list := []FileMeta{}
	for _, meta := range b.fileMeta {
		list = append(list, meta)
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(list)
}

// fetchShardAdaptive races every candidate node holding a copy of one shard
// (normally the primary and its backup) against each other and returns
// whichever checksum-valid copy lands first, cancelling the loser(s). This
// is the "adaptive" part of the read path: rather than a fixed
// primary-then-backup sequence, both are always tried at once so a slow or
// degraded primary can't stall the read - the backup wins on its own merit.
func (b *Backend) fetchShardAdaptive(ctx context.Context, fileID string, shardIdx uint32, checksum string, nodeIDs ...string) []byte {
	raceCtx, cancel := context.WithCancel(ctx)
	defer cancel()

	type result struct {
		data []byte
		ok   bool
	}
	resCh := make(chan result, len(nodeIDs))

	var wg sync.WaitGroup
	for _, nodeID := range nodeIDs {
		if nodeID == "" {
			resCh <- result{}
			continue
		}
		wg.Add(1)
		go func(nodeID string) {
			defer wg.Done()
			data, _, err := b.cc.GetShard(raceCtx, nodeID, fileID, shardIdx)
			if err != nil || len(data) == 0 || !verifyChecksum(data, checksum) {
				resCh <- result{}
				return
			}
			resCh <- result{data: data, ok: true}
		}(nodeID)
	}
	go func() { wg.Wait(); close(resCh) }()

	for r := range resCh {
		if r.ok {
			cancel() // we have a winner; stop whichever node hasn't answered yet
			return r.data
		}
	}
	return nil
}

// downloadFileAdaptive is the primary read path: for the cluster's fixed 4
// data + 2 parity Reed-Solomon layout, all rsTotalShards (6) shard fetches
// are fanned out at once (each one itself racing primary vs. backup via
// fetchShardAdaptive, covering the 2 backup nodes). As soon as
// meta.DataShards (4) of them land successfully, the remaining stragglers
// are cancelled and the file is reconstructed - no need to wait on shards
// the RS math doesn't actually need. Concurrent downloads of the same
// fileID are collapsed into a single execution via sfGroup, so a burst of
// repeat requests for a hot file only does the fetch/reconstruct work once.
func (b *Backend) downloadFileAdaptive(fileID string) ([]byte, string, error) {
	atomic.AddInt64(&b.sfTotal, 1)

	fileOut, name, err, shared := b.sfGroup.Do(fileID, func() ([]byte, string, error) {
		b.mu.RLock()
		meta, exists := b.fileMeta[fileID]
		b.mu.RUnlock()
		if !exists {
			return nil, "", fmt.Errorf("file not found")
		}

		ctx, cancelAll := context.WithCancel(context.Background())
		defer cancelAll()

		shards := make([][]byte, rsTotalShards)

		type shardResult struct {
			idx  int
			data []byte
		}
		resCh := make(chan shardResult, len(meta.Mappings))

		for i, mapping := range meta.Mappings {
			idx := i
			chunkID := fmt.Sprintf("%s_%s", fileID, mapping.ShardID)
			shardIdx := shardIndexOf(mapping.ShardID)
			primary := meta.ChunkMap[chunkID]
			backup := meta.BackupMap[chunkID]
			checksum := meta.ChecksumMap[chunkID]

			go func() {
				data := b.fetchShardAdaptive(ctx, fileID, shardIdx, checksum, primary, backup)
				resCh <- shardResult{idx: idx, data: data}
			}()
		}

		successes, received := 0, 0
		for received < len(meta.Mappings) {
			r := <-resCh
			received++
			shards[r.idx] = r.data
			if r.data != nil {
				successes++
				if successes >= meta.DataShards {
					cancelAll() // enough shards in hand; stop waiting on the rest
					break
				}
			}
		}

		fileOut, err := reconstructAndJoin(shards, meta.DataShards, meta.ParityShards, meta.ShardSize, meta.Size)
		if err != nil {
			return nil, "", err
		}
		return fileOut, meta.Name, nil
	})

	if shared {
		atomic.AddInt64(&b.sfDeduped, 1)
	}
	return fileOut, name, err
}

// HandleStats reports singleflight dedup stats for the dashboard.
func (b *Backend) HandleStats(w http.ResponseWriter, r *http.Request) {
	stats := map[string]int64{
		"download_requests": atomic.LoadInt64(&b.sfTotal),
		"deduped_requests":  atomic.LoadInt64(&b.sfDeduped),
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(stats)
}

// HandleDownload serves a file download using the adaptive singleflight
// path above, falling back to the original sequential
// primary-then-backup-then-heal path if the adaptive path fails for any
// reason (e.g. a shard genuinely unavailable everywhere it looked).
func (b *Backend) HandleDownload(w http.ResponseWriter, r *http.Request) {
	fileID := r.URL.Query().Get("id")
	if fileID == "" {
		fileID = r.URL.Query().Get("file")
	}

	if fileOut, name, err := b.downloadFileAdaptive(fileID); err == nil {
		w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", name))
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Write(fileOut)
		b.touchLastAccessed(fileID)
		return
	}

	b.downloadFileSequentialFallback(w, fileID, "attachment")
	b.touchLastAccessed(fileID)
}

// HandleView serves a file for inline in-browser viewing (images, PDFs,
// text) rather than forcing a download - same fetch path as
// HandleDownload (adaptive first, sequential fallback second), same
// touchLastAccessed bump, and since it goes through downloadFileAdaptive
// -> fetchShardAdaptive -> the cluster's CacheEngine, it exercises the same
// 2Q cache hit/miss counters as a normal download.
func (b *Backend) HandleView(w http.ResponseWriter, r *http.Request) {
	fileID := r.URL.Query().Get("id")
	if fileID == "" {
		fileID = r.URL.Query().Get("file")
	}

	if fileOut, name, err := b.downloadFileAdaptive(fileID); err == nil {
		w.Header().Set("Content-Disposition", fmt.Sprintf("inline; filename=\"%s\"", name))
		w.Header().Set("Content-Type", contentTypeFor(name, "inline"))
		w.Write(fileOut)
		b.touchLastAccessed(fileID)
		return
	}

	b.downloadFileSequentialFallback(w, fileID, "inline")
	b.touchLastAccessed(fileID)
}

// HandleCacheStats reports each node's real 2Q cache hit/miss counters and
// queue occupancy, plus a cluster-wide aggregate - this is the actual
// cache-efficiency signal (distinct from /stats' singleflight dedup count,
// which measures something else: concurrent requests piggybacking on one
// in-flight download, not 2Q hits).
func (b *Backend) HandleCacheStats(w http.ResponseWriter, r *http.Request) {
	b.mu.RLock()
	defer b.mu.RUnlock()

	perNode := make(map[string]CacheStats, len(b.nodeEngines))
	var total CacheStats
	for id, engine := range b.nodeEngines {
		if engine == nil {
			continue
		}
		s := engine.Stats()
		perNode[id] = s
		total.MemHits += s.MemHits
		total.DiskHits += s.DiskHits
		total.Misses += s.Misses
	}

	totalAccesses := total.MemHits + total.DiskHits + total.Misses
	hitRate := 0.0
	if totalAccesses > 0 {
		// THE FIX: Only RAM hits count as a "Cache Hit". 
		// Fetching from disk (DiskHits) or failing entirely (Misses) are both cache misses.
		hitRate = float64(total.MemHits) / float64(totalAccesses) * 100
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"nodes":        perNode,
		"total":        total,
		"hit_rate_pct": hitRate,
	})
}

// touchLastAccessed updates a file's LastAccessed timestamp and persists it,
// so the sweeper's 30-day TTL check and LRU capacity eviction both reflect
// real usage instead of treating every file as equally stale.
func (b *Backend) touchLastAccessed(fileID string) {
	b.mu.Lock()
	meta, exists := b.fileMeta[fileID]
	b.mu.Unlock()
	if !exists {
		return
	}
	meta.LastAccessed = time.Now().Unix()
	_ = b.saveMeta(fileID, meta)
}

// downloadFileSequentialFallback is the original download implementation:
// fetch each shard from its primary, fail over to its backup, heal a new
// backup copy when needed, and reconstruct. Kept as-is and used only when
// the adaptive path above can't complete the download.
func (b *Backend) downloadFileSequentialFallback(w http.ResponseWriter, fileID string, disposition string) {
	ctx := context.Background()

	b.mu.Lock()
	meta, exists := b.fileMeta[fileID]
	if !exists {
		b.mu.Unlock()
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}

	metadataUpdated := false
	shards := make([][]byte, rsTotalShards)

	for idx, mapping := range meta.Mappings {
		chunkID := fmt.Sprintf("%s_%s", fileID, mapping.ShardID)
		shardIdx := shardIndexOf(mapping.ShardID)
		primaryNode := meta.ChunkMap[chunkID]
		if primaryNode == "" {
			primaryNode = mapping.NodeID
		}

		data, _, err := b.cc.GetShard(ctx, primaryNode, fileID, shardIdx)
		if err == nil && len(data) > 0 && !verifyChecksum(data, meta.ChecksumMap[chunkID]) {
			err, data = fmt.Errorf("corrupt shard"), nil
		}

		if err != nil || len(data) == 0 {
			backupNode := meta.BackupMap[chunkID]
			data, _, err = b.cc.GetShard(ctx, backupNode, fileID, shardIdx)
			if err == nil && len(data) > 0 && !verifyChecksum(data, meta.ChecksumMap[chunkID]) {
				err, data = fmt.Errorf("corrupt shard"), nil
			}
			if err != nil || len(data) == 0 {
				// Missing on primary and backup; Reed-Solomon may still
				// recover it as long as total losses stay within parity.
				shards[idx] = nil
				continue
			}

			if newBackupNode := b.findHealthyNode(primaryNode, backupNode); newBackupNode != "" {
				checksum := meta.ChecksumMap[chunkID]
				if putErr := b.cc.PutShard(ctx, newBackupNode, fileID, shardIdx, data, checksum); putErr == nil {
					meta.ChunkMap[chunkID] = newBackupNode
					meta.Mappings[idx].NodeID = newBackupNode
					metadataUpdated = true
				}
			}
		}

		shards[idx] = data
	}

	if metadataUpdated {
		b.saveMeta(fileID, meta)
	}

	fileOut, err := reconstructAndJoin(shards, meta.DataShards, meta.ParityShards, meta.ShardSize, meta.Size)
	b.mu.Unlock()
	if err != nil {
		http.Error(w, fmt.Sprintf("Critical error: %v", err), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Disposition", fmt.Sprintf("%s; filename=\"%s\"", disposition, meta.Name))
	w.Header().Set("Content-Type", contentTypeFor(meta.Name, disposition))
	w.Write(fileOut)
}

// contentTypeFor picks a real MIME type by file extension for inline
// viewing (so the browser can render images/PDF/text instead of just
// downloading them); attachment downloads keep the generic
// application/octet-stream they've always used, since forcing a save
// dialog is the point there.
func contentTypeFor(name, disposition string) string {
	if disposition != "inline" {
		return "application/octet-stream"
	}
	if ct := mime.TypeByExtension(filepath.Ext(name)); ct != "" {
		return ct
	}
	return "application/octet-stream"
}

// findHealthyNode picks a random online backup node, excluding the given two.
func (b *Backend) findHealthyNode(exclude1, exclude2 string) string {
	var available []string
	for nodeID := range b.backupNodes {
		if nodeID == exclude1 || nodeID == exclude2 {
			continue
		}
		if _, exists := b.nodeAddrs[nodeID]; exists && b.cc.PingNode(nodeID) {
			available = append(available, nodeID)
		}
	}
	if len(available) == 0 {
		return ""
	}

	rGen := rand.New(rand.NewSource(time.Now().UnixNano()))
	rGen.Shuffle(len(available), func(i, j int) { available[i], available[j] = available[j], available[i] })
	return available[0]
}

// HandleDelete removes a file's metadata and its chunks from every node.
func (b *Backend) HandleDelete(w http.ResponseWriter, r *http.Request) {
	fileID := r.URL.Query().Get("id")
	if fileID == "" {
		fileID = r.URL.Query().Get("file")
	}

	b.mu.RLock()
	meta, exists := b.fileMeta[fileID]
	b.mu.RUnlock()

	if !exists {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}

	// Delete from Raft ledger
	leaderNode := b.getLeader()
	if leaderNode != nil {
		cmd := LogCommand{Op: "DELETE_META", Key: fileID}
		cmdBytes, _ := json.Marshal(cmd)
		leaderNode.Apply(cmdBytes, 5*time.Second)
	}

	ctx := context.Background()
	for _, mapping := range meta.Mappings {
		chunkID := fmt.Sprintf("%s_%s", fileID, mapping.ShardID)
		shardIdx := shardIndexOf(mapping.ShardID)
		_ = b.cc.DeleteShard(ctx, meta.ChunkMap[chunkID], fileID, shardIdx)
		_ = b.cc.DeleteShard(ctx, meta.BackupMap[chunkID], fileID, shardIdx)
	}

	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Deleted successfully"))
}

// getDiskUsagePercentage returns the used disk space percentage cross-platform.
func getDiskUsagePercentage(path string) (float64, error) {
	usage, err := disk.Usage(path)
	if err != nil {
		return 0, err
	}
	return usage.UsedPercent, nil
}

// deleteFilePermanently removes the file from the Raft ledger and physical storage.
func (b *Backend) deleteFilePermanently(fileID string) {
	leaderNode := b.getLeader()
	if leaderNode != nil {
		cmd := LogCommand{Op: "DELETE_META", Key: fileID}
		cmdBytes, _ := json.Marshal(cmd)
		leaderNode.Apply(cmdBytes, 5*time.Second)
	}

	ctx := context.Background()
	b.mu.RLock()
	meta, exists := b.fileMeta[fileID]
	b.mu.RUnlock()

	if exists {
		for _, mapping := range meta.Mappings {
			chunkID := fmt.Sprintf("%s_%s", fileID, mapping.ShardID)
			shardIdx := shardIndexOf(mapping.ShardID)
			_ = b.cc.DeleteShard(ctx, meta.ChunkMap[chunkID], fileID, shardIdx)
			_ = b.cc.DeleteShard(ctx, meta.BackupMap[chunkID], fileID, shardIdx)
		}
	}
}

// startUnifiedSweeper runs both the 30-day TTL eviction and the capacity-based LRU eviction.
func (b *Backend) startUnifiedSweeper(storagePath string, highWaterMark, lowWaterMark float64) {
	ticker := time.NewTicker(5 * time.Minute)

	go func() {
		for range ticker.C {
			now := time.Now().Unix()
			thirtyDays := int64(30 * 24 * 60 * 60)

			var timeExpiredFiles []string
			var capacityCandidates []FileMeta

			b.mu.RLock()
			for id, meta := range b.fileMeta {
				if meta.IsPinned {
					continue
				}
				// Phase 1: 30-Day Check
				if (now - meta.LastAccessed) > thirtyDays {
					timeExpiredFiles = append(timeExpiredFiles, id)
				} else {
					capacityCandidates = append(capacityCandidates, meta)
				}
			}
			b.mu.RUnlock()

			// Execute Phase 1
			for _, fileID := range timeExpiredFiles {
				b.deleteFilePermanently(fileID)
				fmt.Printf("[Sweeper] Evicted abandoned 30-day file: %s\n", fileID)
			}

			// Phase 2: Capacity-based LRU Check
			usedPercent, err := getDiskUsagePercentage(storagePath)
			if err != nil {
				fmt.Printf("[Sweeper] Error checking disk space: %v\n", err)
				continue
			}

			if usedPercent >= highWaterMark {
				fmt.Printf("[Sweeper] WARNING: Disk usage at %.2f%%. Triggering capacity eviction...\n", usedPercent)

				// Sort remaining unpinned files by oldest LastAccessed (LRU)
				sort.Slice(capacityCandidates, func(i, j int) bool {
					return capacityCandidates[i].LastAccessed < capacityCandidates[j].LastAccessed
				})

				for _, meta := range capacityCandidates {
					currentPercent, _ := getDiskUsagePercentage(storagePath)
					if currentPercent <= lowWaterMark {
						fmt.Printf("[Sweeper] Disk usage stabilized at %.2f%%. Eviction halted.\n", currentPercent)
						break
					}

					b.deleteFilePermanently(meta.ID)
					fmt.Printf("[Sweeper] Evicted oldest file to free capacity: %s\n", meta.ID)
				}
			}
		}
	}()
}

// HandleTogglePin flips the IsPinned status of a file to protect it from deletion
func (b *Backend) HandleTogglePin(w http.ResponseWriter, r *http.Request) {
	fileID := r.URL.Query().Get("id")

	b.mu.RLock()
	meta, exists := b.fileMeta[fileID]
	b.mu.RUnlock()

	if !exists {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}

	// Flip the pin status
	meta.IsPinned = !meta.IsPinned

	// Save back to Raft metadata consensus
	if err := b.saveMeta(fileID, meta); err != nil {
		http.Error(w, "Consensus failed: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	// Add this new handler to Backend
}
func (b *Backend) HandleCacheInspect(w http.ResponseWriter, r *http.Request) {
	b.mu.RLock()
	defer b.mu.RUnlock()

	clusterCache := make(map[string]CacheContents)
	for id, engine := range b.nodeEngines {
		if engine != nil {
			clusterCache[id] = engine.Inspect()
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(clusterCache)
}
