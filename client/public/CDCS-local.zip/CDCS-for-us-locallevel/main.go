package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/hashicorp/raft"
	"google.golang.org/grpc"
)

func main() {
	// gRPC addresses for the storage nodes (CacheService & ReplicationService)
	nodeAddrs := map[string]string{
		"Node-01": "127.0.0.1:50051",
		"Node-02": "127.0.0.1:50052",
		"Node-03": "127.0.0.1:50053",
		"Node-04": "127.0.0.1:50054",
		"Node-05": "127.0.0.1:50055",
		"Node-06": "127.0.0.1:50056",
		"Node-07": "127.0.0.1:50057",
		"Node-08": "127.0.0.1:50058",
	}

	// Dedicated TCP addresses for Raft consensus chatter
	raftAddrs := map[string]string{
		"Raft-01": "127.0.0.1:60051",
		"Raft-02": "127.0.0.1:60052",
		"Raft-03": "127.0.0.1:60053",
		"Raft-04": "127.0.0.1:60054",
		"Raft-05": "127.0.0.1:60055",
		"Raft-06": "127.0.0.1:60056",
		"Raft-07": "127.0.0.1:60057",
		
	}

	runningServers := make(map[string]*grpc.Server)
	nodeEngines := make(map[string]*TwoQEngine)

	// Boot up the gRPC storage engine for all 8 nodes
	for id, addr := range nodeAddrs {
		srv, engine, err := StartNode(id, addr)
		if err != nil {
			log.Printf("Warning: Failed to start %s: %v\n", id, err)
		} else {
			runningServers[id] = srv
			nodeEngines[id] = engine
			fmt.Printf("Started gRPC node %s on %s\n", id, addr)
		}
	}

	// Initialize the backend and wire it to the gRPC servers
	backend := NewBackend(nodeAddrs, runningServers, nodeEngines)
	
	// Setup the Raft control plane structures inside the backend
	backend.raftNodes = make(map[string]*raft.Raft)
	backend.raftAddrs = raftAddrs

	// Start the Raft Consensus on active nodes only
	activeRafts := []string{"Raft-01", "Raft-02", "Raft-03", "Raft-04", "Raft-05"}
	for _, id := range activeRafts {
		addr := raftAddrs[id]
		rNode, err := SetupRaft(id, addr, raftAddrs, backend.db, backend.fileMeta, &backend.mu)
		if err != nil {
			log.Fatalf("Failed to start Raft on %s: %v", id, err)
		}
		backend.raftNodes[id] = rNode
		fmt.Printf("Started Raft consensus on %s on %s\n", id, addr)
	}

	// Core Cluster API Endpoints
	http.HandleFunc("/nodes", backend.HandleNodes)
	http.HandleFunc("/kill", backend.HandleKillNode)
	http.HandleFunc("/upload", backend.HandleUpload)
	http.HandleFunc("/files", backend.HandleFiles)
	http.HandleFunc("/download", backend.HandleDownload)
	http.HandleFunc("/view", backend.HandleView)
	http.HandleFunc("/cache-stats", backend.HandleCacheStats)
	http.HandleFunc("/cache-inspect", backend.HandleCacheInspect)
	http.HandleFunc("/delete", backend.HandleDelete)
	http.HandleFunc("/revive", backend.HandleReviveNode)
	
// Raft Dashboard Status Endpoint
	
	http.HandleFunc("/raft/status", func(w http.ResponseWriter, r *http.Request) {
		var status []map[string]interface{}
		
		backend.mu.RLock()
		defer backend.mu.RUnlock()

		seen := make(map[string]bool)

		// 1. Read the stats from all ACTIVE Raft instances
		for id, rNode := range backend.raftNodes {
			stats := rNode.Stats()
			status = append(status, map[string]interface{}{
				"id":           id,
				"address":      backend.raftAddrs[id], // <-- ADDED THIS LINE
				"state":        stats["state"],
				"term":         stats["term"],
				"commit_index": stats["commit_index"],
				"leader":       rNode.Leader(),
			})
			seen[id] = true
		}
		
		// 2. Inject the SLEEPING backup nodes
		for _, backupID := range backend.standbyRaft {
			status = append(status, map[string]interface{}{
				"id":           backupID,
				"address":      backend.raftAddrs[backupID], // <-- ADDED THIS LINE
				"state":        "Backup",
				"term":         "-",
				"commit_index": "-",
				"leader":       "-",
			})
			seen[backupID] = true
		}

		// 3. Inject the OFFLINE nodes 
		for id := range backend.raftAddrs {
			if !seen[id] {
				status = append(status, map[string]interface{}{
					"id":           id,
					"address":      backend.raftAddrs[id], // <-- ADDED THIS LINE
					"state":        "Dead",
					"term":         "-",
					"commit_index": "-",
					"leader":       "-",
				})
			}
		}
		
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(status)
	})
	// Serve the Main File Storage Dashboard
	http.Handle("/", http.FileServer(http.Dir(".")))
    http.HandleFunc("/stats", backend.HandleStats)
	// Inside your HTTP router setup in main.go:
    http.HandleFunc("/pin", backend.HandleTogglePin)
	
	fmt.Println("Unified Cluster Dashboard running at http://localhost:8080")
	
	
	if err := http.ListenAndServe(":8080", nil); err != nil {
		log.Fatal(err)
	}
}