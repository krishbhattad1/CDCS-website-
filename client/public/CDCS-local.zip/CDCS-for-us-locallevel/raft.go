package main

import (
	"encoding/json"
	"io"
	"net"
	"sync"
	"time"

	"github.com/cockroachdb/pebble"
	"github.com/hashicorp/go-hclog"
	"github.com/hashicorp/raft"
)

type LogCommand struct {
	Op   string   `json:"op"`
	Key  string   `json:"key"`
	Data FileMeta `json:"data,omitempty"`
}

type MetadataFSM struct {
	db       *pebble.DB
	fileMeta map[string]FileMeta
	mu       *sync.RWMutex
}

func (fsm *MetadataFSM) Apply(l *raft.Log) interface{} {
	var cmd LogCommand
	if err := json.Unmarshal(l.Data, &cmd); err != nil {
		return err
	}

	fsm.mu.Lock()
	defer fsm.mu.Unlock()

	switch cmd.Op {
	case "SET_META":
		fsm.fileMeta[cmd.Key] = cmd.Data
		metaBytes, _ := json.Marshal(cmd.Data)
		return fsm.db.Set([]byte("file:"+cmd.Key), metaBytes, pebble.Sync)
	case "DELETE_META":
		delete(fsm.fileMeta, cmd.Key)
		return fsm.db.Delete([]byte("file:"+cmd.Key), pebble.Sync)
	}
	return nil
}

func (fsm *MetadataFSM) Snapshot() (raft.FSMSnapshot, error) { return &fsmSnapshot{}, nil }
func (fsm *MetadataFSM) Restore(rc io.ReadCloser) error      { return nil }

type fsmSnapshot struct{}
func (s *fsmSnapshot) Persist(sink raft.SnapshotSink) error { return sink.Close() }
func (s *fsmSnapshot) Release()                             {}

func SetupRaft(localID string, localAddr string, clusterAddrs map[string]string, db *pebble.DB, meta map[string]FileMeta, mu *sync.RWMutex) (*raft.Raft, error) {
	config := raft.DefaultConfig()
	config.LocalID = raft.ServerID(localID)
	
	config.HeartbeatTimeout = 250 * time.Millisecond
	config.LeaderLeaseTimeout = 250 * time.Millisecond
	config.ElectionTimeout = 600 * time.Millisecond
	config.CommitTimeout = 50 * time.Millisecond

	// COMPLETE SILENCE: Throw all Raft logs into the void
	logger := hclog.New(&hclog.LoggerOptions{
		Name:   localID,
		Output: io.Discard, 
	})
	config.Logger = logger

	// IN-MEMORY STORAGE: Fixes all "Revive" file-lock crashes
	logStore := raft.NewInmemStore()
	stableStore := raft.NewInmemStore()
	snapshotStore := raft.NewDiscardSnapshotStore()

	tcpAddr, err := net.ResolveTCPAddr("tcp", localAddr)
	if err != nil { return nil, err }

	transport, err := raft.NewTCPTransportWithLogger(localAddr, tcpAddr, 3, 10*time.Second, logger)
	if err != nil { return nil, err }

	fsm := &MetadataFSM{db: db, fileMeta: meta, mu: mu}
	raftNode, err := raft.NewRaft(config, fsm, logStore, stableStore, snapshotStore, transport)
	if err != nil { return nil, err }

	if localID == "Raft-01" {
		var servers []raft.Server
		for id, addr := range clusterAddrs {
			servers = append(servers, raft.Server{ ID: raft.ServerID(id), Address: raft.ServerAddress(addr) })
		}
		raftNode.BootstrapCluster(raft.Configuration{Servers: servers})
	}

	return raftNode, nil
}