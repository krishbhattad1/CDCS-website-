package main

import (
	"context"
	"fmt"
	"time"

	pb "cdcs/cdcs/cdcspb"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

// ClusterClient is the single place gRPC connections to other nodes are
// made and used. backend.go talks to the cluster only through this type -
// it no longer dials/calls gRPC itself.
type ClusterClient struct {
	cacheClients map[string]pb.CacheServiceClient
	replClients  map[string]pb.ReplicationServiceClient
}

// maxShardMsgSize sets the gRPC message size ceiling for shard traffic.
// gRPC's built-in default is 4MB in both directions; any shard bigger than
// that would fail PushShard against the main nodes with ResourceExhausted
// and silently fall back to the two backup-only nodes for every shard.
// Set in GB so it's easy to size against your largest expected file.
const maxShardMsgSizeGB = 1
const maxShardMsgSize = maxShardMsgSizeGB << 30 // GB -> bytes

func NewClusterClient(nodes map[string]string) *ClusterClient {
	cacheClients := make(map[string]pb.CacheServiceClient)
	replClients := make(map[string]pb.ReplicationServiceClient)
	for id, addr := range nodes {
		conn, err := grpc.Dial(
			addr,
			grpc.WithTransportCredentials(insecure.NewCredentials()),
			grpc.WithDefaultCallOptions(
				grpc.MaxCallSendMsgSize(maxShardMsgSize),
				grpc.MaxCallRecvMsgSize(maxShardMsgSize),
			),
		)
		if err == nil {
			cacheClients[id] = pb.NewCacheServiceClient(conn)
			replClients[id] = pb.NewReplicationServiceClient(conn)
		}
	}
	return &ClusterClient{cacheClients: cacheClients, replClients: replClients}
}

// PingNode does a fast health check against a node using its CacheService.
func (c *ClusterClient) PingNode(nodeID string) bool {
	client, exists := c.cacheClients[nodeID]
	if !exists {
		return false
	}

	ctx, cancel := context.WithTimeout(context.Background(), 200*time.Millisecond)
	defer cancel()

	_, err := client.Get(ctx, &pb.GetRequest{Key: "__health_check__"})
	return err == nil
}

// PutShard pushes one Reed-Solomon shard to nodeID via ReplicationService.
func (c *ClusterClient) PutShard(ctx context.Context, nodeID, fileID string, shardIndex uint32, shardData []byte, checksum string) error {
	client, exists := c.replClients[nodeID]
	if !exists {
		return fmt.Errorf("node %s not found", nodeID)
	}

	ack, err := client.PushShard(ctx, &pb.ShardPushRequest{
		Key:        fileID,
		ShardIndex: shardIndex,
		ShardData:  shardData,
		Checksum:   checksum,
	})
	if err != nil {
		return err
	}
	if !ack.Ok {
		return fmt.Errorf("node %s rejected shard write", nodeID)
	}
	return nil
}

// GetShard fetches one Reed-Solomon shard from nodeID via ReplicationService.
func (c *ClusterClient) GetShard(ctx context.Context, nodeID, fileID string, shardIndex uint32) ([]byte, string, error) {
	client, exists := c.replClients[nodeID]
	if !exists {
		return nil, "", fmt.Errorf("node %s not found", nodeID)
	}

	res, err := client.FetchShard(ctx, &pb.ShardFetchRequest{
		Key:        fileID,
		ShardIndex: shardIndex,
	})
	if err != nil {
		return nil, "", err
	}
	if res.Error != nil {
		return nil, "", fmt.Errorf("%s", res.Error.Message)
	}
	return res.ShardData, res.Checksum, nil
}

// DeleteShard removes one shard from nodeID via ReplicationService, so it
// clears the same CacheEngine entry PushShard/FetchShard use.
//
// Requires the DeleteShard RPC added to cdcs.proto - regenerate cdcspb
// (protoc) before this compiles.
func (c *ClusterClient) DeleteShard(ctx context.Context, nodeID, fileID string, shardIndex uint32) error {
	client, exists := c.replClients[nodeID]
	if !exists {
		return fmt.Errorf("node %s not found", nodeID)
	}

	ack, err := client.DeleteShard(ctx, &pb.ShardDeleteRequest{
		Key:        fileID,
		ShardIndex: shardIndex,
	})
	if err != nil {
		return err
	}
	if !ack.Ok {
		return fmt.Errorf("node %s rejected shard delete", nodeID)
	}
	return nil
}