curl "http://localhost:8080/revive?id=Raft-01"
curl "http://localhost:8080/kill?id=Raft-01"
