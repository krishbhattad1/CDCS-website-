package main

import (
	"context"
	"fmt"
	"net"

	"google.golang.org/grpc"

	pb "cdcs/cdcs/cdcspb"
)

// StorageNode implements ReplicationService only. CacheService (Get/Put/
// Delete) is handled by server.Server. Both now share the exact same
// CacheEngine instance (a TwoQEngine) - shard reads/writes/deletes go
// through it just like plain key/value traffic does, so file upload,
// download, and view all actually exercise the 2Q cache (hit/miss counters,
// eviction, promotion) instead of a separate untracked map+disk path.
type StorageNode struct {
	pb.UnimplementedReplicationServiceServer
	id     string
	engine CacheEngine
}

// maxShardMsgSize (defined once in cdcs.go, usable here since both files
// are package main) also caps the server's receive/send size. gRPC's
// built-in default is 4MB in both directions; without raising it here too,
// large shards get rejected with ResourceExhausted regardless of what the
// client allows - gRPC enforces whichever side is stricter.

func StartNode(id string, addr string) (*grpc.Server, *TwoQEngine, error) {
	lis, err := net.Listen("tcp", addr)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to listen on %s: %v", addr, err)
	}

	grpcServer := grpc.NewServer(
		grpc.MaxRecvMsgSize(maxShardMsgSize),
		grpc.MaxSendMsgSize(maxShardMsgSize),
	)

	// Using the new TwoQEngine with a memory capacity of 1000 keys
	engine, err := NewTwoQEngine(id, 2)
	if err != nil {
		return nil, nil, err
	}
	cacheServer := NewServer(engine)

	nodeServer := &StorageNode{
		id:     id,
		engine: engine,
	}

	pb.RegisterCacheServiceServer(grpcServer, cacheServer)
	pb.RegisterReplicationServiceServer(grpcServer, nodeServer)

	go func() {
		if err := grpcServer.Serve(lis); err != nil {
			fmt.Printf("Node %s stopped listening.\n", id)
		}
	}()

	return grpcServer, engine, nil
}

// ReplicationService implementation - used by backend.go (via client.go) to
// push/fetch/delete individual Reed-Solomon shards, separate from the plain
// key/value CacheService traffic. Both services now share one CacheEngine
// per node, so a shard is a completely ordinary cache entry as far as the
// 2Q policy is concerned.
func (s *StorageNode) PushShard(ctx context.Context, req *pb.ShardPushRequest) (*pb.ShardAck, error) {
	key := fmt.Sprintf("%s_shard_%d", req.Key, req.ShardIndex)
	if err := s.engine.Put(ctx, key, req.ShardData, false); err != nil {
		return &pb.ShardAck{Ok: false, Error: &pb.ErrorDetail{Code: pb.ErrorCode_INTERNAL, Message: err.Error()}}, nil
	}
	return &pb.ShardAck{Ok: true}, nil
}

func (s *StorageNode) FetchShard(ctx context.Context, req *pb.ShardFetchRequest) (*pb.ShardFetchResponse, error) {
	key := fmt.Sprintf("%s_shard_%d", req.Key, req.ShardIndex)
	data, found, err := s.engine.Get(ctx, key, false)
	if err != nil || !found {
		return &pb.ShardFetchResponse{
			Error: &pb.ErrorDetail{Code: pb.ErrorCode_SHARD_UNAVAILABLE, Message: "Shard not found"},
		}, nil
	}
	return &pb.ShardFetchResponse{ShardData: data, Checksum: shardChecksum(data)}, nil
}

// DeleteShard requires the DeleteShard RPC added to cdcs.proto's
// ReplicationService. Regenerate the cdcspb package (protoc) before this
// will compile - see cdcs.proto for the new rpc/message definitions.
func (s *StorageNode) DeleteShard(ctx context.Context, req *pb.ShardDeleteRequest) (*pb.ShardAck, error) {
	key := fmt.Sprintf("%s_shard_%d", req.Key, req.ShardIndex)
	if err := s.engine.Delete(ctx, key, false); err != nil {
		return &pb.ShardAck{Ok: false, Error: &pb.ErrorDetail{Code: pb.ErrorCode_INTERNAL, Message: err.Error()}}, nil
	}
	return &pb.ShardAck{Ok: true}, nil
}

func (s *StorageNode) Heartbeat(ctx context.Context, req *pb.HeartbeatRequest) (*pb.HeartbeatResponse, error) {
	return &pb.HeartbeatResponse{Ok: true, ReplicationLagMs: 0}, nil
}