package main

import (
	"context"
	"fmt"

	pb "cdcs/cdcs/cdcspb"
)
type Server struct {
	pb.UnimplementedCacheServiceServer
	engine CacheEngine
}
func NewServer(engine CacheEngine) *Server {
	return &Server{engine: engine}
}
func (s *Server) Get(ctx context.Context, req *pb.GetRequest) (*pb.GetResponse, error) {
	// SAFETY FIX: Intercept health checks so they don't pollute 2Q cache stats
	if req.Key == "__health_check__" {
		return &pb.GetResponse{Found: true}, nil
	}

	val, found, err := s.engine.Get(ctx, req.Key, req.Linearizable)
	if err != nil {
		return &pb.GetResponse{
			Found: false,
			Error: &pb.ErrorDetail{
				Code:    pb.ErrorCode_INTERNAL,
				Message: fmt.Sprintf("failed to get key: %v", err),
			},
		}, nil
	}
	if !found {
		return &pb.GetResponse{
			Found: false,
			Error: &pb.ErrorDetail{
				Code:    pb.ErrorCode_KEY_NOT_FOUND,
				Message: "key not found",
			},
		}, nil
	}
	return &pb.GetResponse{Value: val, Found: true}, nil
}
func (s *Server) Put(ctx context.Context, req *pb.PutRequest) (*pb.PutResponse, error) {
	err := s.engine.Put(ctx, req.Key, req.Value, false)
	if err != nil {
		return &pb.PutResponse{
			Applied: false,
			Error: &pb.ErrorDetail{
				Code:    pb.ErrorCode_INTERNAL,
				Message: fmt.Sprintf("failed to put key: %v", err),
			},
		}, nil
	}
	return &pb.PutResponse{Applied: true}, nil
}
func (s *Server) Delete(ctx context.Context, req *pb.DeleteRequest) (*pb.DeleteResponse, error) {
	err := s.engine.Delete(ctx, req.Key, false)
	if err != nil {
		return &pb.DeleteResponse{
			Applied: false,
			Error: &pb.ErrorDetail{
				Code:    pb.ErrorCode_INTERNAL,
				Message: fmt.Sprintf("failed to delete key: %v", err),
			},
		}, nil
	}
	return &pb.DeleteResponse{Applied: true}, nil
}