package main

import (
	"fmt"

	"github.com/klauspost/reedsolomon"
)

const (
	rsDataShards   = 4
	rsParityShards = 2
	rsTotalShards  = rsDataShards + rsParityShards // 6
)

func newRSEncoder() (reedsolomon.Encoder, error) {
	return reedsolomon.New(rsDataShards, rsParityShards)
}

// encodeFileToShards pads fileBytes so it divides evenly across
// rsDataShards, computes the rsParityShards parity shards on top of it, and
// returns all rsTotalShards shards plus the per-shard (padded) size.
func encodeFileToShards(fileBytes []byte) (shards [][]byte, shardSize int, err error) {
	shardSize = (len(fileBytes) + rsDataShards - 1) / rsDataShards
	if shardSize == 0 {
		shardSize = 1
	}

	padded := make([]byte, shardSize*rsDataShards)
	copy(padded, fileBytes)

	shards = make([][]byte, rsTotalShards)
	for i := 0; i < rsDataShards; i++ {
		shards[i] = padded[i*shardSize : (i+1)*shardSize]
	}
	for i := rsDataShards; i < rsTotalShards; i++ {
		shards[i] = make([]byte, shardSize)
	}

	enc, err := newRSEncoder()
	if err != nil {
		return nil, 0, fmt.Errorf("failed to init Reed-Solomon encoder: %w", err)
	}
	if err := enc.Encode(shards); err != nil {
		return nil, 0, fmt.Errorf("failed to compute Reed-Solomon parity shards: %w", err)
	}

	return shards, shardSize, nil
}

// reconstructAndJoin takes a slice of rsTotalShards shards (nil where a shard
// could not be recovered from either its primary or backup node), rebuilds
// any missing pieces via Reed-Solomon (tolerates up to rsParityShards
// simultaneous losses), and returns the original file bytes trimmed back
// down to originalSize.
func reconstructAndJoin(shards [][]byte, dataShards, parityShards int, shardSize int, originalSize int64) ([]byte, error) {
	missing := 0
	for _, s := range shards {
		if s == nil {
			missing++
		}
	}

	if missing > parityShards {
		return nil, fmt.Errorf("lost %d shard(s), which exceeds Reed-Solomon parity capacity (%d)", missing, parityShards)
	}

	if missing > 0 {
		enc, err := reedsolomon.New(dataShards, parityShards)
		if err != nil {
			return nil, fmt.Errorf("failed to init Reed-Solomon encoder: %w", err)
		}
		if err := enc.Reconstruct(shards); err != nil {
			return nil, fmt.Errorf("Reed-Solomon reconstruction failed: %w", err)
		}
	}

	out := make([]byte, 0, dataShards*shardSize)
	for i := 0; i < dataShards; i++ {
		out = append(out, shards[i]...)
	}

	if int64(len(out)) > originalSize {
		out = out[:originalSize]
	}

	return out, nil
}