package main

import (
	"container/list"
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

type CacheEngine interface {
	Get(ctx context.Context, key string, linearizable bool) ([]byte, bool, error)
	Put(ctx context.Context, key string, value []byte, isLinearizable bool) error
	Delete(ctx context.Context, key string, isLinearizable bool) error
	Stats() CacheStats
}

// CacheStats is a point-in-time snapshot of one node's cache efficiency and
// queue occupancy, used by backend.go's /cache-stats endpoint so the
// dashboard can show real hit/miss numbers instead of only the singleflight
// dedup count.
type CacheStats struct {
	MemHits   int64 `json:"mem_hits"`   // found in a1in/am without touching disk
	DiskHits  int64 `json:"disk_hits"`  // found on disk, not yet tracked in memory
	Misses    int64 `json:"misses"`     // not found anywhere
	A1InSize  int   `json:"a1in_size"`
	AmSize    int   `json:"am_size"`
	A1OutSize int   `json:"a1out_size"` // ghost entries
	Capacity  int   `json:"capacity"`
}
type CacheContents struct {
	A1in  []string `json:"a1in"`
	Am    []string `json:"am"`
	A1out []string `json:"a1out"`
}
type queueType int

const (
	qA1in queueType = iota
	qAm
)

type cacheEntry struct {
	key   string
	value []byte
	qType queueType
}

// TwoQEngine implements CacheEngine with a 2Q (FIFO + LRU) memory eviction policy.
// It persists all writes to disk to survive restarts.
type TwoQEngine struct {
	mu      sync.Mutex
	nodeDir string

	capacity int
	a1inCap  int
	amCap    int
	a1outCap int

	// Queues
	a1in  *list.List
	am    *list.List
	a1out *list.List

	// Hash maps for O(1) lookups
	items  map[string]*list.Element // Stores items in A1in and Am
	ghosts map[string]*list.Element // Stores items in A1out (keys only)

	// Efficiency counters, read by Stats(). Protected by mu like everything
	// else in this engine - Get/Put/Delete already hold it.
	memHits  int64
	diskHits int64
	misses   int64
}

// NewTwoQEngine initializes a new disk-backed 2Q Cache Engine.
func NewTwoQEngine(nodeID string, totalCapacity int) (*TwoQEngine, error) {
	dir := filepath.Join("node_storage", nodeID)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("failed to create storage dir for %s: %w", nodeID, err)
	}

	return &TwoQEngine{
		nodeDir:  dir,
		capacity: totalCapacity,
		a1inCap:  totalCapacity / 4, // 25% for new items
		amCap:    totalCapacity - (totalCapacity / 4),
		a1outCap: totalCapacity / 2, // Ghost cache holds 50% capacity of keys
		a1in:     list.New(),
		am:       list.New(),
		a1out:    list.New(),
		items:    make(map[string]*list.Element),
		ghosts:   make(map[string]*list.Element),
	}, nil
}

func (e *TwoQEngine) Get(ctx context.Context, key string, linearizable bool) ([]byte, bool, error) {
	e.mu.Lock()
	defer e.mu.Unlock()

	// Case 1: Item is currently in memory
	if el, ok := e.items[key]; ok {
		ent := el.Value.(*cacheEntry)
		// If in Am (LRU), move to front. If in A1in (FIFO), do nothing.
		if ent.qType == qAm {
			e.am.MoveToFront(el)
		}
		e.memHits++
		return ent.value, true, nil
	}

	// Read from disk since it's not in memory
	diskData, err := os.ReadFile(filepath.Join(e.nodeDir, key))
	if err != nil {
		e.misses++
		return nil, false, nil // Key not found
	}

	// Case 2: Item is in the ghost cache (A1out). This means it was accessed recently.
	// Promote it to the Am (LRU) queue.
	if el, ok := e.ghosts[key]; ok {
		e.a1out.Remove(el)
		delete(e.ghosts, key)
		e.addToAm(key, diskData)
		e.diskHits++
		return diskData, true, nil
	}

	// Case 3: Completely new access. Add to A1in (FIFO).
	e.addToA1in(key, diskData)
	e.diskHits++
	return diskData, true, nil
}

// Stats returns a snapshot of this engine's hit/miss counters and current
// queue occupancy.
func (e *TwoQEngine) Stats() CacheStats {
	e.mu.Lock()
	defer e.mu.Unlock()
	return CacheStats{
		MemHits:   e.memHits,
		DiskHits:  e.diskHits,
		Misses:    e.misses,
		A1InSize:  e.a1in.Len(),
		AmSize:    e.am.Len(),
		A1OutSize: e.a1out.Len(),
		Capacity:  e.capacity,
	}
}

func (e *TwoQEngine) Put(ctx context.Context, key string, value []byte, isLinearizable bool) error {
	e.mu.Lock()
	defer e.mu.Unlock()

	// Update memory if it already exists
	if el, ok := e.items[key]; ok {
		ent := el.Value.(*cacheEntry)
		ent.value = value
		if ent.qType == qAm {
			e.am.MoveToFront(el)
		}
	} else {
		// New items go to A1in
		e.addToA1in(key, value)
	}

	// Persist to disk
	return os.WriteFile(filepath.Join(e.nodeDir, key), value, 0644)
}

func (e *TwoQEngine) Delete(ctx context.Context, key string, isLinearizable bool) error {
	e.mu.Lock()
	defer e.mu.Unlock()

	if el, ok := e.items[key]; ok {
		ent := el.Value.(*cacheEntry)
		if ent.qType == qA1in {
			e.a1in.Remove(el)
		} else {
			e.am.Remove(el)
		}
		delete(e.items, key)
	}

	if el, ok := e.ghosts[key]; ok {
		e.a1out.Remove(el)
		delete(e.ghosts, key)
	}

	_ = os.Remove(filepath.Join(e.nodeDir, key))
	return nil
}

// --- Internal Queue Management ---

func (e *TwoQEngine) addToA1in(key string, value []byte) {
	if e.a1in.Len() >= e.a1inCap {
		// Evict from A1in to A1out (Ghost)
		evictEl := e.a1in.Back()
		if evictEl != nil {
			evictEnt := evictEl.Value.(*cacheEntry)
			e.a1in.Remove(evictEl)
			delete(e.items, evictEnt.key)

			// Add to A1out
			e.addToA1out(evictEnt.key)
		}
	}
	el := e.a1in.PushFront(&cacheEntry{key: key, value: value, qType: qA1in})
	e.items[key] = el
}

func (e *TwoQEngine) addToAm(key string, value []byte) {
	if e.am.Len() >= e.amCap {
		// Evict from Am (LRU). Items evicted from Am are forgotten completely in memory.
		evictEl := e.am.Back()
		if evictEl != nil {
			evictEnt := evictEl.Value.(*cacheEntry)
			e.am.Remove(evictEl)
			delete(e.items, evictEnt.key)
		}
	}
	el := e.am.PushFront(&cacheEntry{key: key, value: value, qType: qAm})
	e.items[key] = el
}

func (e *TwoQEngine) addToA1out(key string) {
	if e.a1out.Len() >= e.a1outCap {
		evictEl := e.a1out.Back()
		if evictEl != nil {
			e.a1out.Remove(evictEl)
			delete(e.ghosts, evictEl.Value.(string))
		}
	}
	el := e.a1out.PushFront(key)
	e.ghosts[key] = el
	// Add this near your CacheStats struct
type CacheContents struct {
	A1in  []string `json:"a1in"`
	Am    []string `json:"am"`
	A1out []string `json:"a1out"`
}
}
// Add this method to TwoQEngine
func (e *TwoQEngine) Inspect() CacheContents {
	e.mu.Lock()
	defer e.mu.Unlock()

	var contents CacheContents

	// Extract FIFO (Probation) keys
	for el := e.a1in.Front(); el != nil; el = el.Next() {
		contents.A1in = append(contents.A1in, el.Value.(*cacheEntry).key)
	}
	
	// Extract LRU (Hot) keys
	for el := e.am.Front(); el != nil; el = el.Next() {
		contents.Am = append(contents.Am, el.Value.(*cacheEntry).key)
	}
	
	// Extract Ghost (Watchlist) keys
	for el := e.a1out.Front(); el != nil; el = el.Next() {
		contents.A1out = append(contents.A1out, el.Value.(string))
	}

	return contents
}
